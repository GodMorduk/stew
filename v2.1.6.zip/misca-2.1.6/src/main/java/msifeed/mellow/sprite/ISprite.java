package msifeed.mellow.sprite;

import msifeed.mellow.utils.Geom;

public interface ISprite {
    void render(Geom geom);
}
