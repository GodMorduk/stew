package msifeed.misca.keeper;

import java.util.HashMap;
import java.util.Map;

public class KeeperCharsheet {
    public Map<String, Integer> special_stats = new HashMap<>();
    public Map<String, Integer> attributes = new HashMap<>();
    public Map<String, Integer> skills = new HashMap<>();
    public Map<String, Integer> efforts = new HashMap<>();
}
