package msifeed.misca.locks;

public enum LockType {
    mechanical, magical
}
