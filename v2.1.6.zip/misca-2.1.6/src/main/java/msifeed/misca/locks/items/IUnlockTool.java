package msifeed.misca.locks.items;

public interface IUnlockTool {
}
