package msifeed.misca.charstate;

import net.minecraft.util.ResourceLocation;

public class ItemEffectInfo {
    public ResourceLocation effect;
    public int duration = 0;
    public int amplifier = 0;
}
