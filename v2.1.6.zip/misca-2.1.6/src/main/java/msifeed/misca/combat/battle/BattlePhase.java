package msifeed.misca.combat.battle;

public enum BattlePhase {
    INIT, WAIT, ACTION
}
