package msifeed.misca.combat.rules;

public enum WeaponTrait {
    melee, range,
    magic,
    evadeMelee, evadeRange,
    canUse, canHoldUse
}
