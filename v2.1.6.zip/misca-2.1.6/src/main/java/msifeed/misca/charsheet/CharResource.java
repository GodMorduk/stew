package msifeed.misca.charsheet;

public enum CharResource {
    est, ord, seal
}
